package com.example.Cinemaxify;

public class NormalPlan implements Plan {

	@Override
	public String getPlanName() {
		// TODO Auto-generated method stub
		return "normal";
	}

}
