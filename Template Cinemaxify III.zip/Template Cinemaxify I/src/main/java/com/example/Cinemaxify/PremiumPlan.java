package com.example.Cinemaxify;

public class PremiumPlan implements Plan {

	@Override
	public String getPlanName() {
		// TODO Auto-generated method stub
		return "premium";
	}

}
